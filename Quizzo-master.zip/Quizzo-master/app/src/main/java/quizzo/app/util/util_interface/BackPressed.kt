package quizzo.app.util.util_interface

interface BackPressed {
    fun backPressed()
}