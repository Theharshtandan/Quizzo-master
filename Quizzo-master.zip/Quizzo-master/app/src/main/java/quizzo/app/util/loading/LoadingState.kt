package quizzo.app.util.loading

enum class LoadingState {
    IDLE,
    LOADING,
    COMPLETED,
    ERROR
}