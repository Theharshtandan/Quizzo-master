package quizzo.app.util.enums

enum class MatchStatus {
    WIN,
    LOSE,
    DRAW,
    NONE
}