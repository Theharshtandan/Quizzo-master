package quizzo.app.util.enums

enum class MatchType {
    SINGLE_PLAYER,
    MULTI_PLAYER,
    MULTI_PLAYER_BOT,
}