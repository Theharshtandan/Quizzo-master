package quizzo.app.util.category

data class Category(
    val name: String,
    val imageId: Int
)