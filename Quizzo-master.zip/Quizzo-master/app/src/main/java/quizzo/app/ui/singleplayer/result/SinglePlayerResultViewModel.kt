package quizzo.app.ui.singleplayer.result

import androidx.lifecycle.ViewModel
import quizzo.app.data.repository.QuizzoRepository

class SinglePlayerResultViewModel(private val repo: QuizzoRepository) : ViewModel() {
    fun addMatchToHistory() {}
}
