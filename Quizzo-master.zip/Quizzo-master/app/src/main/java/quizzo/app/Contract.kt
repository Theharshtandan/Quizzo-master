package quizzo.app

class Contract {
    companion object {
        const val QUIZZO_SERVER_URL= "<--Enter your Quizzo api url here-->"
        const val WRITE_KEY= "<--Enter the R/W access key for your database-->"
    }
}